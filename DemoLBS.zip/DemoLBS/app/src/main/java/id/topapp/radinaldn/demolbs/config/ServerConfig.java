package id.topapp.radinaldn.demolbs.config;

/**
 * Created by radinaldn on 22/10/18.
 */

public class ServerConfig {
    public static final String API_ENDPOINT = "http://192.168.1.103/smart-app/";
}
